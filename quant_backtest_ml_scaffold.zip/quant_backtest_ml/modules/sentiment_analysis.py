def score_sentiment(text):
    pass
