def create_volume_bars():
    pass

def add_indicators():
    pass
