def evaluate_model():
    pass
