def prepare_features():
    pass

def train_classifier():
    pass
