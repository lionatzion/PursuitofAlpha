from modules.model_training import train_classifier

def main():
    train_classifier()

if __name__=="__main__":
    main()
