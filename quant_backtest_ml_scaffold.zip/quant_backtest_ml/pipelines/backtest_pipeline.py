from modules.backtesting_workflow import run_backtest

def main():
    run_backtest()

if __name__=="__main__":
    main()
