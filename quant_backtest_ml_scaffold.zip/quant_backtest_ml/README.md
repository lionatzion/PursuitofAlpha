# Quant Backtest Machine Learning Project

This scaffold sets up a modular project for quantitative trading strategies with ML and sentiment analysis.
